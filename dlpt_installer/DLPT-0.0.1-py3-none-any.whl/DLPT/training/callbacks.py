'''
Implements callbacks to be executed during training loop
'''
import time
from typing import Sequence

from torch import Tensor


class Callback():
    '''
    Abstract representation of a callable. All callables should extend this class.
    '''
    def __call__(self):
        raise NotImplementedError


class Test(Callback):
    def __init__(self):
        super(Test, self).__init__()

    def __call__(self, inputs: Tensor, labels: Tensor, outputs=None) -> Sequence:
        pass
        if outputs is None:
            return inputs, labels
        else:
            return inputs, labels, outputs


class Delay(Callback):
    '''
    Delays computation by s seconds
    '''
    def __init__(self, s=0):
        super(Delay, self).__init__()
        self.s = s

    def __call__(self, inputs: Tensor, labels: Tensor, outputs=None) -> Sequence:
        time.sleep(self.s)
        if outputs is None:
            return inputs, labels
        else:
            return inputs, labels, outputs
