'''
This package contains codes related to the training loops and handling training statistics

>>Most of these modules have being DEPRECATED in favor of using PyTorch Lightning<<
'''
import time
import os
from os.path import join as merge_paths
import copy
import logging

import numpy as np
import torch
import torch.nn as nn
from torch.optim import Optimizer

from DLPT.training.results import Results
from DLPT.loss import Loss


logging.warning("Training package is DEPRECATED in favor of using PyTorch Lightning")


def train(model: nn.Module, loss_function: Loss, metrics: list, optimizer: Optimizer, dataloaders: dict, device: torch.device,
          nepochs: int, savefolder: str, experiment_name: str, scheduler=None, patience=None, pre_forward_callbacks=[],
          post_forward_callbacks=[], **kwargs) -> Results:
    '''
    This function trains parameters in the model object, using giving auxiliary objects

    model: model class instantiation
    loss: loss object, should support a __call__
    metrics: list of metrics to be used, can be only one or none. The FIRST METRIC is considered the reference metric.
    optimizer: optimizer object from pytorch, or wrapper
    dataloaders: torch
    '''
    if not isinstance(metrics, list):
        logging.warning("Metrics argument is not a list.")
        metrics = [metrics]

    if not os.path.isdir(savefolder):
        logging.info("Savefolder {} not found, attempting to create it.")
        os.makedirs(savefolder)

    results = Results(experiment_name, loss_name=loss_function.name, metric_names=[metric.name for metric in metrics])

    since = time.time()

    best_model_wts = copy.deepcopy(model.state_dict())
    metric_names = [metric.name for metric in metrics]

    main_metric_name = metric_names[0]
    main_metric = metrics[0]
    logging.info("Selected {} as main metric".format(main_metric_name))
    try:
        # For each epoch
        for epoch in range(nepochs):
            logging.info('Epoch {}/{}'.format(epoch + 1, nepochs))
            logging.info('-' * 10)

            # Perform trainig and validation
            for phase in ['train', 'validation']:
                if phase == 'train':
                    model.train()
                else:
                    model.eval()

                running_loss = 0.0
                running_accs = np.zeros(len(metrics))

                # In a EPOCH, iterate over all batches
                for inputs, labels in dataloaders[phase]:
                    for callback in pre_forward_callbacks:
                        inputs, labels = callback(inputs, labels)

                    inputs = inputs.to(device)
                    labels = labels.to(device)

                    optimizer.zero_grad()

                    # Use gradients only in training phase, loss and metric should be batch means!
                    with torch.set_grad_enabled(phase == 'train'):
                        outputs = model(inputs)

                        for callback in post_forward_callbacks:
                            inputs, labels, outputs = callback(inputs, labels, outputs)

                        loss = loss_function(outputs, labels)
                        accs = np.array([metric(outputs, labels) for metric in metrics])

                        # Backpropagation only in trainig phase
                        if phase == 'train':
                            loss.backward()
                            optimizer.step()

                    # Batch statistics, multiplies by batch size due to dividing by dataset size later
                    running_loss += loss.item()
                    running_accs = running_accs + accs

                if phase == "train" and scheduler is not None:
                    logging.info("Scheduler step called.")
                    scheduler.step()

                # Get epoch statistics
                nbatches = len(dataloaders[phase])
                epoch_loss = running_loss / nbatches
                epoch_accs = running_accs / nbatches
                main_metric_result = epoch_accs[0]
                metric_dict = {}
                for metric_name, metric in zip(metric_names, epoch_accs):
                    metric_dict[metric_name] = metric

                # Check patience
                patient = True
                if patience is not None and phase == patience.mode:
                    patient = patience(results, metric_dict[patience.reference])

                # Save weights
                if phase == "validation" and results.check_best_yet(main_metric_result, "validation", main_metric_name,
                                                                    lower_is_best=main_metric.lower_is_best):
                    torch.save(model.state_dict(), merge_paths(savefolder, experiment_name + ".pt"))
                    best_model_wts = copy.deepcopy(model.state_dict())
                    logging.info("Best model so far, saving.")

                # Store in results object
                results.append_to(phase, loss_function.name, epoch_loss)
                for name, metric in metric_dict.items():
                    results.append_to(phase, name, metric)

                if not patient:
                    raise KeyboardInterrupt("Patience interrupt")

    except KeyboardInterrupt as ki:
        logging.info("Training interrupted by {}".format(ki))

    time_elapsed = time.time() - since
    logging.info("Training complete in {:.0f}m {:.0f}s".format(time_elapsed//60, time_elapsed % 60))
    best_acc = results.get_best("validation", main_metric_name, lower_is_best=main_metric.lower_is_best)
    logging.info('Best validation accuracy ({}): {:4f}'.format(main_metric_name, best_acc))

    # Return best model and result history
    model.load_state_dict(best_model_wts)
    results.save(merge_paths(savefolder, experiment_name))

    return results


def train_test(display=False, nepochs=5):
    '''
    Tests training loop in a simple case. Copied word for word from
    https://pytorch.org/tutorials/beginner/transfer_learning_tutorial.html, except the training loop.
    '''
    from multiprocessing import cpu_count

    from torch.optim import lr_scheduler
    from torchvision import datasets, models, transforms

    from loss.cross_entropy import CrossEntropyLoss
    from optimizers.radam import RAdam
    from metrics.classification import Accuracy
    from training.patience import DefaultPatience
    from utils.device import get_device
    from training.callbacks import Test

    logging.info("Testing results module.\n")

    # Data augmentation and normalization for training
    # Just normalization for validation
    data_transforms = {
        'train': transforms.Compose([
            transforms.RandomResizedCrop(224),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ]),
        'validation': transforms.Compose([
            transforms.Resize(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ]),
    }

    data_dir = 'data/hymenoptera_data'
    image_datasets = {x: datasets.ImageFolder(os.path.join(data_dir, x), data_transforms[x])
                      for x in ['train', 'validation']}
    dataloaders = {x: torch.utils.data.DataLoader(image_datasets[x], batch_size=100, shuffle=True,
                                                  num_workers=cpu_count())
                   for x in ['train', 'validation']}

    device = get_device()

    # Get a batch of training data
    inputs, classes = next(iter(dataloaders['train']))

    model_ft = models.resnet18(pretrained=True)
    num_ftrs = model_ft.fc.in_features
    # Here the size of each output sample is set to 2.
    # Alternatively, it can be generalized to nn.Linear(num_ftrs, len(class_names)).
    model_ft.fc = nn.Linear(num_ftrs, 2)

    model_ft = model_ft.to(device)

    loss_function = CrossEntropyLoss()
    metric = Accuracy()

    # Observe that all parameters are being optimized
    optimizer_ft = RAdam(model_ft.parameters())

    # Decay LR by a factor of 0.1 every 7 epochs
    exp_lr_scheduler = lr_scheduler.StepLR(optimizer_ft, step_size=nepochs//2, gamma=0.1)

    patience = DefaultPatience(nepochs//4, lower_is_best=metric.lower_is_best, mode="validation", reference=metric.name)

    results = train(model_ft, loss_function, [metric], optimizer_ft, dataloaders, device, nepochs, "cache", "training_test",
                    scheduler=exp_lr_scheduler, patience=patience, pre_forward_callbacks=[Test()],
                    post_forward_callbacks=[Test()])

    logging.info(results.log)

    if display:
        results.plot()

    logging.info("Training test completed without errors.\n")
