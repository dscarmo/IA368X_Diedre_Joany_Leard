'''
Utilities related to using opencv for displays
'''
import cv2 as cv


def image_print(img, st, org=(20, 20), scale=1, color=1, font=cv.FONT_HERSHEY_SIMPLEX):
    '''
    Simplifies printing text on images
    '''
    if st is None:
        return img
    else:
        return cv.putText(img, str(st), org, font, scale, color)
