'''
Working with the PyTorch Lightning wrapper
This test will become a template for future experiments using lightning and DLPT
'''
# Standard Library
import os
import logging
from glob import glob
from argparse import Namespace

# External Libraries
import numpy as np

# Pytorch Lightning
import pytorch_lightning as pl
from pytorch_lightning import Trainer
from pytorch_lightning.loggers import TensorBoardLogger
from pytorch_lightning.callbacks import EarlyStopping, ModelCheckpoint

# DLPT
from DLPT.loss.cross_entropy import CrossEntropyLoss
from DLPT.models.attunet_3d import AttU_Net_3D
from DLPT.metrics.metric_calculator import EvalMetricCalculator
from DLPT.metrics.classification import Accuracy
from DLPT.transforms.to_tensor import ToTensor
from DLPT.transforms.patches import CenterCrop
from DLPT.transforms.intensity import RandomIntensity
from DLPT.transforms.noise import RandomGaussianNoise
from DLPT.transforms import Compose
from DLPT.datasets.brats import BRATS
from DLPT.optimizers.radam import RAdam

# Tensorboard
tensorboard = "data/tensorboard_debug"

# Hyperparameters
loss_fn = CrossEntropyLoss()
metric_fn = EvalMetricCalculator(Accuracy(), segmentation=False)

transforms = Compose([CenterCrop(128, 128, 128, segmentation=False, assert_big_enough=True),
                      RandomIntensity(), RandomGaussianNoise(), ToTensor(volumetric=True, classify=True)])
test_transforms = Compose([CenterCrop(128, 128, 128, segmentation=False, assert_big_enough=True),
                           ToTensor(volumetric=True, classify=True)])

hyperparameters = {"experiment_name": "debug",
                   "lr": 0.0001, "bs": 2, "test_bs": 1, "patience": 200, "factor": 16, "max_epochs": 200,
                   "transforms": str(transforms), "test_transforms": str(test_transforms),
                   "opt": "RAdam",
                   "loss": loss_fn.name, "metric": metric_fn.name, "dataset": "BratS", "dataset_year": "2019",
                   "splits": "(0.7, 0.1, 0.2)", "kfold": "None", "fold": "None"}
#


class BRATSTest(pl.LightningModule):
    def __init__(self, hparams):
        super(BRATSTest, self).__init__()
        global loss_fn, metric_fn

        self.hparams = hparams
        self.loss = loss_fn
        self.accuracy = metric_fn
        self.model = AttU_Net_3D(img_ch=4, output_ch=1, factor=self.hparams.factor, classify=True, nouts=2)

    def forward(self, x):
        '''
        Sums outputs of passing efficient net through all slices and returns average activations
        '''
        return self.model(x)

    def training_step(self, batch, batch_idx):
        '''
        Runs every batch
        '''
        x, _, y, _, _ = batch
        y_hat = self.forward(x)
        logging.debug(y_hat)
        loss = self.loss(y_hat, y)
        tensorboard_logs = {'loss': loss}

        return {'loss': loss, 'log': tensorboard_logs}

    def validation_step(self, batch, batch_idx):
        '''
        Runs every batch
        '''
        x, _, y, _, _ = batch
        y_hat = self.forward(x)
        loss = self.loss(y_hat, y).item()
        acc = self.accuracy(y_hat, y)
        return {'val_loss_batch': loss, 'val_acc_batch': acc}

    def validation_epoch_end(self, outputs):
        '''
        Runs after calculating validation for all batches
        '''
        main_metric_name = self.accuracy.metric.name

        avg_loss = np.array([x['val_loss_batch'] for x in outputs]).mean()
        avg_acc = np.array([x['val_acc_batch'][main_metric_name] for x in outputs]).mean()

        avg_prec = np.array([x['val_acc_batch']["prec"] for x in outputs]).mean()
        avg_rec = np.array([x['val_acc_batch']["rec"] for x in outputs]).mean()
        avg_spec = np.array([x['val_acc_batch']["spec"] for x in outputs]).mean()

        tensorboard_logs = {'val_loss': avg_loss, 'val_acc': avg_acc,
                            'val_precision': avg_prec, 'val_recall': avg_rec, 'val_specificity': avg_spec}
        tqdm_dict = {"val_loss": avg_loss, "val_acc": avg_acc}

        return {'val_loss': avg_loss, 'val_acc': avg_acc, 'log': tensorboard_logs, 'progress_bar': tqdm_dict}

    def test_step(self, batch, batch_idx):
        x, _, y, _, _ = batch
        y_hat = self.forward(x)
        loss = self.loss(y_hat, y).item()
        acc = self.accuracy(y_hat, y)
        return {'test_loss_batch': loss, "test_acc_batch": acc}

    def test_epoch_end(self, outputs):
        main_metric_name = self.accuracy.metric.name

        avg_loss = np.array([x['test_loss_batch'] for x in outputs]).mean()
        avg_acc = np.array([x['test_acc_batch'][main_metric_name] for x in outputs]).mean()

        avg_prec = np.array([x['test_acc_batch']["prec"] for x in outputs]).mean()
        avg_rec = np.array([x['test_acc_batch']["rec"] for x in outputs]).mean()
        avg_spec = np.array([x['test_acc_batch']["spec"] for x in outputs]).mean()

        tensorboard_logs = {'test_loss': avg_loss, 'test_acc': avg_acc,
                            'test_precision': avg_prec, 'test_recall': avg_rec, 'test_specificity': avg_spec}
        tqdm_dict = {"test_loss": avg_loss, "test_acc": avg_acc}

        return {'test_loss': avg_loss, 'test_acc': avg_acc, 'log': tensorboard_logs, 'progress_bar': tqdm_dict}

    def configure_optimizers(self):
        return RAdam(self.parameters(), lr=self.hparams.lr)

    def train_dataloader(self):
        global transforms
        return BRATS(self.hparams.dataset_year, "default", "all", "train", sep_mode='holdout', splits=eval(self.hparams.splits),
                     transform=transforms).get_dataloader(batch_size=self.hparams.bs, shuffle=True, num_workers=2)

    def val_dataloader(self):
        global transforms
        return BRATS(self.hparams.dataset_year, "default", "all", "validation", sep_mode='holdout',
                     splits=eval(self.hparams.splits), transform=transforms).get_dataloader(batch_size=self.hparams.bs,
                                                                                            shuffle=False,
                                                                                            num_workers=2)

    def test_dataloader(self):
        global test_transforms
        return BRATS(self.hparams.dataset_year, "default", "all", "test", sep_mode='holdout', splits=eval(self.hparams.splits),
                     transform=test_transforms).get_dataloader(batch_size=self.hparams.test_bs, shuffle=False,
                                                               num_workers=2)


def test_lightning(display=False, long_test=False):
    global hyperparameters, tensorboard

    # Instantiate model
    model = BRATSTest(Namespace(**hyperparameters))

    # Folder management
    experiment_name = hyperparameters["experiment_name"]
    model_folder = os.path.join(tensorboard, experiment_name)
    os.makedirs(model_folder, exist_ok=True)

    # Callback initialization
    early_stop_callback = EarlyStopping(monitor='val_acc', patience=hyperparameters["patience"], verbose=False, mode='max')
    checkpoint_callback = ModelCheckpoint(prefix=experiment_name, filepath=model_folder, monitor="val_acc", mode="max")
    logger = TensorBoardLogger(tensorboard, experiment_name)

    # PL Trainer initialization
    trainer = Trainer(gpus=1, precision=32, checkpoint_callback=checkpoint_callback, early_stop_callback=early_stop_callback,
                      logger=logger, max_epochs=hyperparameters["max_epochs"], fast_dev_run=not long_test,
                      progress_bar_refresh_rate=1)

    # Train
    trainer.fit(model)

    # Reload best model
    ckpt_path = glob(os.path.join(tensorboard, experiment_name, "*.ckpt"))[-1]
    loaded_model = BRATSTest.load_from_checkpoint(ckpt_path)

    # Test
    trainer.test(loaded_model)
