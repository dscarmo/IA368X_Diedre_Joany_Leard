'''
Useful statistics
'''


def stats(obj, name=''):
    return {f"{name} sum": obj.sum(),
            f"{name} mean": obj.mean(),
            f"{name} std": obj.std(),
            f"{name} max": obj.max(),
            f"{name} min": obj.min()}
