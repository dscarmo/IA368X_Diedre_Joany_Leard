import numpy as np
import logging
import copy

from DLPT.metrics import Metric
from DLPT.utils.mri import split_l_r
from DLPT.metrics.segmentation import precision, recall, specificity


class EvalMetricCalculator(Metric):
    def __init__(self, metric, segmentation, do_splits=False):
        '''
        For testing time ease of STD report

        metric: main metric class
        segmentation: wether this is a segmentation or a classification problem
        '''
        self.name = metric.name + "+SPR"
        self.lower_is_best = "False"
        super(EvalMetricCalculator, self).__init__()
        self.metric = metric
        self.segmentation = segmentation
        self.do_splits = do_splits
        self.accs, self.laccs, self.raccs, self.specs, self.precs, self.recs = [], [], [], [], [], []

    def __call__(self, preds, tgt):
        preds = preds.float()
        tgt = tgt.float()

        self.metrics = self.return_eval_metrics(preds, tgt)
        self.accs.append(self.metrics[self.metric.name])
        if self.segmentation and self.do_splits:
            self.laccs.append(self.metrics['l' + self.metric.name])
            self.raccs.append(self.metrics['r' + self.metric.name])
        self.specs.append(self.metrics["spec"])
        self.precs.append(self.metrics["prec"])
        self.recs.append(self.metrics["rec"])

        return copy.deepcopy(self.metrics)

    def final_results(self):
        npaccs = np.array(self.accs)
        mean, std = npaccs.mean(), npaccs.std()

        if self.segmentation and self.do_splits:
            lnpaccs = np.array(self.laccs)
            lmean, lstd = lnpaccs.mean(), lnpaccs.std()

            rnpaccs = np.array(self.raccs)
            rmean, rstd = rnpaccs.mean(), rnpaccs.std()

        npspecs = np.array(self.specs)
        specsmean, specsstd = npspecs.mean(), npspecs.std()

        nprec = np.array(self.recs)
        recmean, recstd = nprec.mean(), nprec.std()

        npprec = np.array(self.precs)
        precmean, precstd = npprec.mean(), npprec.std()

        result = ''
        result += "{} Mean: {}, std: {}\n".format(self.metric.name, mean, std)
        if self.segmentation and self.do_splits:
            result += "Left {} mean: {}, std: {}\n".format(self.metric.name, lmean, lstd)
            result += "Right {} mean: {}, std: {}\n".format(self.metric.name, rmean, rstd)
        result += "Specificity mean: {}, std: {}\n".format(specsmean, specsstd)
        result += "Recall mean: {}, std: {}\n".format(recmean, recstd)
        result += "Precision mean: {}, std: {}\n".format(precmean, precstd)
        logging.info(result)
        return result

    def return_eval_metrics(self, preds, tgt):
        if self.segmentation:
            splitted_preds = split_l_r(preds)
            splitted_tgt = split_l_r(tgt)
            if self.do_splits:
                lacc = self.metric(splitted_preds["left"], splitted_tgt["left"])
                racc = self.metric(splitted_preds["right"], splitted_tgt["right"])
            spec = specificity(preds, tgt).item()
            rec = recall(preds, tgt).item()
            prec = precision(preds, tgt).item()
        else:
            classes = preds.argmax(dim=1).long()
            spec = specificity(classes, tgt).item()
            rec = recall(classes, tgt).item()
            prec = precision(classes, tgt).item()

        metric = self.metric(preds, tgt)

        if self.segmentation:
            if self.do_splits:
                return {self.metric.name: metric, 'l' + self.metric.name: lacc, 'r' + self.metric.name: racc,
                        "spec": spec, "prec": prec, "rec": rec}
            else:
                return {self.metric.name: metric, "spec": spec, "prec": prec, "rec": rec}

        else:
            return {self.metric.name: metric, "spec": spec, "prec": prec, "rec": rec}


def test_metric_calculator(display=False, long_test=False):
    import torch
    from DLPT.metrics.classification import Accuracy

    metric = Accuracy()
    emc = EvalMetricCalculator(metric, segmentation=False)
    simulated_output = torch.randn(30, 2).softmax(dim=1)
    simulated_target = torch.randint(0, 2, (30,))
    emc(simulated_output, simulated_target)
    logging.info("Random O: {}, T: {}".format(simulated_output, simulated_target))
    emc.final_results()

    emc = EvalMetricCalculator(metric, segmentation=False)
    simulated_output = torch.tensor([[0, 1], [1, 0], [0.6, 0.4]])
    simulated_target = torch.tensor([1, 0, 0])
    emc(simulated_output, simulated_target)
    logging.info("Specific test O: {}, T: {}".format(simulated_output, simulated_target))
    emc.final_results()
