'''
From Boundary Loss for Higly Unbalanced Segmentation
'''
import torch
from torch import einsum
from torch import Tensor
import numpy as np
from typing import List

from DLPT.loss import Loss
from DLPT.loss.gdl import GeneralizedDice
from DLPT.utils.asserts import one_hot, simplex


class SurfaceLoss(Loss):
    def __init__(self, **kwargs):
        # Self.idc is used to filter out some classes of the target mask. Use fancy indexing
        self.name = "Surface Loss"
        super().__init__()
        self.idc: List[int] = kwargs["idc"]
        self.dim = kwargs["dim"] if "dim" in kwargs else 2
        print(f"Initialized {self.__class__.__name__} with {kwargs}")

    def __call__(self, probs: Tensor, dist_maps: Tensor, _: Tensor) -> Tensor:
        assert simplex(probs)
        assert not one_hot(dist_maps)

        pc = probs[:, self.idc, ...].type(torch.float32)
        dc = dist_maps[:, self.idc, ...].type(torch.float32)

        if self.dim == 2:
            multipled = einsum("bcwh,bcwh->bcwh", pc, dc)
        elif self.dim == 3:
            multipled = einsum("bcdwh,bcdwh->bcdwh", pc, dc)
        else:
            raise ValueError("Only supporting 2D or 3D")

        loss = multipled.mean()

        return loss


class BoundaryLoss(Loss):
    def __init__(self, **kwargs):
        '''
        Init weights refers to weights for: GDL, Surface
        Ideally, increment should be called once per epoch
        '''
        self.name = "Boundary Loss"
        super(BoundaryLoss, self).__init__()
        self.idc: List[int] = kwargs["idc"]
        self.max_ncalls: int = kwargs["max_ncalls"]
        self.init_weights = np.array(kwargs["init_weights"])
        self.weights = self.init_weights
        self.dim = kwargs["dim"] if "dim" in kwargs else 2

        assert self.weights.sum() == 1.0
        self.dice_loss = GeneralizedDice(idc=kwargs["idc"], loss=True, dim=self.dim)
        print("Using GDL for Boundary Loss")

        self.surface = SurfaceLoss(idc=kwargs["idc"], dim=self.dim)

        increment_module = abs(self.weights[0] - self.weights[1])/self.max_ncalls
        argmax = self.weights.argmax()

        self.increment = np.array([increment_module, increment_module])
        self.increment[argmax] = -1*self.increment[argmax]

        print(f"Initialized {self.__class__.__name__} with {kwargs}. Per epoch increment: {self.increment}")

    def __call__(self, probs: Tensor, dist_maps: Tensor, target: Tensor) -> Tensor:
        dl_weight, surface_weight = self.weights
        dice_probs = probs
        dice_target = target

        return dl_weight*self.dice_loss(dice_probs, dice_target) + surface_weight*self.surface(probs, dist_maps, target)

    def increment_weights(self):
        pre_increment = self.weights
        self.weights = self.weights + self.increment
        print("Boundary Loss weights: {} -> {}".format(pre_increment, self.weights))

    def reset_weights(self):
        print("Boundary loss weights reset.")
        self.weights = self.init_weights
