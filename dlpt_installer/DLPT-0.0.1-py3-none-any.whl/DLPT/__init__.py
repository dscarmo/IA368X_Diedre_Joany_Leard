'''
This is the main DLPT root package, containing test scripts. Child packages implement training, losses, metrics and so on.
'''
import logging


class TestMessages():
    def __init__(self, name):
        self.name = name

    def long_test(self):
        logging.info("{} long test running. (this will take a while)".format(self.name))

    def start_test(self):
        logging.info("Testing {}.".format(self.name))

    def end_test(self):
        logging.info("{} test completed without errors.\n".format(self.name))
