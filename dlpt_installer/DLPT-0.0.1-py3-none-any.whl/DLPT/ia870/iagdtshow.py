# -*- encoding: utf-8 -*-
# Module iagdtshow

from numpy import *

def iagdtshow(X, N=10):

    import ia636
    return ia636.iaisolines(X,N)

