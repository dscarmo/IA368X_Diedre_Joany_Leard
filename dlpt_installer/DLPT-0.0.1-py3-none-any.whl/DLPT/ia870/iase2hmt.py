# -*- encoding: utf-8 -*-
# Module iase2hmt

from numpy import *

def iase2hmt(A, Bc):


    Iab = (A,Bc)

    return Iab

