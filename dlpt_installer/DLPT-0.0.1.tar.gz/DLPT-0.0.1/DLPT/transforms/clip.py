'''
Functions related to crip transform
'''
from DLPT.transforms import Transform


class Clip(Transform):
    '''
    Clips a given numpy image
    '''
    def __init__(self, high_clip=1.0, low_clip=0.0, segmentation=True):
        self.high = high_clip
        self.low = low_clip
        self.segmentation = segmentation

    def __call__(self, image, mask):
        image[image > 1.0] = 1.0
        image[image < 0.0] = 0.0
        if self.segmentation:
            mask[mask > 1.0] = 1.0
            mask[mask < 0.0] = 0.0

        return image, mask

    def __str__(self):
        return "Clip"
