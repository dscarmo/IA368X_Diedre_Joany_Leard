'''
Implements results storing utilities
'''
import os
import pickle
import copy
import logging
import datetime
from os.path import join as merge_paths
from matplotlib import pyplot as plt

from DLPT.utils.asserts import assert_mode, assert_noformat_path
from DLPT.utils.string import concat_with_space


class Results():
    '''
    Default container for result history. Used by trainer to store history.
    Loss and metrics are referred by their names, eg: Dice, CrossEntropy.
    Contents are saved and loaded by pickle
    '''
    VERSION = "1.0"
    @staticmethod
    def load(filepath: str) -> "Results":
        '''
        loads results from given filepath
        '''
        filepath = assert_noformat_path(filepath, warn_only=True)
        filepath += ".pkl"

        # Check if input is actually a file
        if not os.path.isfile(filepath):
            raise FileNotFoundError("{} not found.".format(filepath))

        # Logic to check presence of duplicates increasing i
        tr = None
        splitpath = os.path.splitext(filepath)
        check_duplicate = filepath
        i = 0
        while os.path.isfile(check_duplicate):
            logging.debug("Found duplicate pkl file {}".format(i))
            i += 1
            previous_path = check_duplicate
            check_duplicate = splitpath[0] + str(i) + splitpath[1]

        # Load newest corresponding file
        with open(previous_path, "rb") as f:
            logging.info("Found stored results in {}. Loading...".format(previous_path))
            tr = pickle.load(f)

        return tr

    def __init__(self, name, loss_name: str, metric_names: list):
        '''
        Give names to initialize dict, saving history and best value
        '''
        logging.debug("Results class version {}.".format(Results.VERSION))
        empty_dict = {"train": [],
                      "validation": []}
        self.name = name
        self.log = {loss_name: copy.deepcopy(empty_dict)}

        for metric_name in metric_names:
            logging.info("Adding {} to results log.".format(metric_name))
            self.log[metric_name] = copy.deepcopy(empty_dict)

        logging.debug("Results initialized with: name: {}, loss_name: {}, metric_names: {}".format(name, loss_name, metric_names))

    def save(self, filepath: str):
        '''
        Saves itself following a path
        '''
        assert_noformat_path(filepath, warn_only=True)

        self.save_date = datetime.datetime.now().date().strftime("-%d_%m_%Y")

        with open(filepath + ".pkl", "wb") as output_file, open(filepath + ".txt", 'w') as output_txt:
            pickle.dump(self, output_file)
            output_txt.write("name: {}\ndate:{}\nlog: {}".format(self.name, self.save_date, self.log))

        logging.info("Results saved in {}".format(filepath))

    def get_names(self) -> list:
        '''
        Returns currently used names of loss/metric(s). Names are alwayes the same in train and validation modes.
        '''
        return list(self.log.keys())

    def append_to(self, mode: str, name: str, value: float):
        '''
        Adds a value to the log of name in the given mode
        '''
        assert_mode(mode)
        assert name in self.log
        logging.info("{} {}: {:.4f}.".format(mode, name, value))
        self.log[name][mode].append(value)

    def get_best(self, mode: str, name: str, lower_is_best=False) -> float:
        '''
        Get best logged metric
        '''
        if lower_is_best:
            return min(self.log[name][mode])
        else:
            return max(self.log[name][mode])

    def check_best_yet(self, value: float, mode: str, name: str, lower_is_best=False) -> bool:
        '''
        Compares a value with logged metrics to see if its the best yet
        '''
        if len(self.log[name][mode]) == 0:
            return True

        if lower_is_best:
            return value < self.get_best(mode, name, lower_is_best=lower_is_best)
        else:
            return value > self.get_best(mode, name, lower_is_best=lower_is_best)

    def plot(self, show=True, split_figures=False, label='', ylim=None, lower_ylim=None):
        '''
        Rewritten result plotting routine, TODO should be improved
        '''
        abbrv_labels = ["train", "val"]

        if not split_figures:
            plt.figure(num=self.name)

        for i, (metric_name, data) in enumerate(self.log.items()):
            epoch_range = range(len(list(data.items())[0][1]))
            if split_figures:
                plt.figure(num=concat_with_space(self.name, metric_name))
            else:
                plt.subplot(1, len(self.log), i + 1)

            for j, mode in enumerate(["train", "validation"]):
                plt.ylabel(metric_name)
                plt.xlabel("Epoch")
                if ylim is not None and lower_ylim is not None:
                    plt.ylim(lower_ylim, ylim)
                plt.plot(epoch_range, data[mode], '-', label=concat_with_space(label, abbrv_labels[j]))
                plt.legend()

        if show:
            plt.show()


def results_test(display=False):
    '''
    Test cases for the Results class.
    '''
    logging.info("Testing results module.\n")
    simulated_values = {"loss": {"train": [0.6, 0.4, 0.2],
                                 "validation": [0.8, 0.6, 0.4]},
                        "metric_1": {"train": [0.7, 0.5, 0.3],
                                     "validation": [0.9, 0.7, 0.5]},
                        "metric_2": {"train": [80, 60, 40],
                                     "validation": [90, 70, 50]}}

    test_results = Results("test", "loss", ["metric_1", "metric_2"])
    metric_names = test_results.get_names()

    assert metric_names == ["loss", "metric_1", "metric_2"]

    for mode in ["train", "validation"]:
        for metric_name in metric_names:
            for i in range(3):
                test_results.append_to(mode, metric_name, simulated_values[metric_name][mode][i])

    assert test_results.check_best_yet(0.1, mode="train", name="loss", lower_is_best=True)
    assert not test_results.check_best_yet(60, mode="validation", name="metric_2", lower_is_best=True)
    assert test_results.check_best_yet(0.9, mode="train", name="metric_1", lower_is_best=False)
    assert not test_results.check_best_yet(80, mode="validation", name="metric_2", lower_is_best=False)

    reference_log = str(test_results.log)
    assert reference_log == str(simulated_values)

    savepath = merge_paths("cache", "test_results")
    test_results.save(savepath)

    reloaded_test = Results.load(savepath)
    current_date = datetime.datetime.now().date().strftime("-%d_%m_%Y")
    assert current_date == reloaded_test.save_date
    assert reference_log == str(reloaded_test.log)

    reloaded_test.plot(show=display, split_figures=False, label="Test 1")
    reloaded_test.plot(show=display, split_figures=True, label="Test 2")

    logging.info("Results test completed without errors.\n")
