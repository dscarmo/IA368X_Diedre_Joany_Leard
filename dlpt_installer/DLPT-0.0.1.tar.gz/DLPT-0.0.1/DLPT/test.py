'''
Testing script for the whole framework. Should be run anytime any change is done to the code.
'''
import logging
import argparse
import sys
sys.path.append("/home/diedre/git/diedre_phd/")  # workaround for testing

from DLPT.datasets.harp import test_harp
from DLPT.datasets.brats import test_brats
from DLPT.utils.cache import clean_all_cache, check_cache
from DLPT.utils.logging import init_logging
from DLPT.models.attunet_3d import test_attunet_3d
from DLPT.models.cnn3d_att import test_cnn3d_att
from DLPT.models.unet import test_unet
from DLPT.lightning import test_lightning
from DLPT.metrics.metric_calculator import test_metric_calculator
from DLPT.metrics.brats import test_brats_metrics
from DLPT.transforms.patches import test_patch
from DLPT import TestMessages


if __name__ == "__main__":
    test_list = {"harp": test_harp, "attunet_3d": test_attunet_3d, "brats": test_brats,
                 "metric_calc": test_metric_calculator, "light": test_lightning, "cnn3datt": test_cnn3d_att,
                 "unet": test_unet, "brats_metrics": test_brats_metrics, "test_patch": test_patch}

    parser = argparse.ArgumentParser()
    parser.add_argument("--debug", "-db", help="Display debug information.", action="store_true")
    parser.add_argument("--display", "-d", help="Display plots.", action="store_true")
    parser.add_argument("--long_test", "-lt", help="Perform more computer intensive tests.", action="store_true")
    parser.add_argument("--select", "-s", help="Select a specific test to run.", default="all")
    parser.add_argument("--exclude", "-e", help="Exclude one of the tests.", default=None)
    args = parser.parse_args()
    init_logging(args.debug)
    logging.info("Starting DLPT tests.\n")
    try:
        if args.exclude is not None:
            logging.info("Removed {} from tests.".format(args.exclude))
            test_list.pop(args.exclude)

        logging.info("Tests are the available tests: {}".format(test_list))

        check_cache()
        for name, test in test_list.items():
            if args.select == "all" or args.select == name:
                tm = TestMessages(name)
                tm.start_test()
                test(display=args.display, long_test=args.long_test)
                tm.end_test()
        clean_all_cache()
    except Exception:
        logging.error("DLPT Tests failed!", exc_info=True)
    else:
        logging.info("All tests completed without errors.")
