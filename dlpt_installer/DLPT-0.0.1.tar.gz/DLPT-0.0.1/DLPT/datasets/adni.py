import os
import logging
import random
from glob import iglob, glob
from typing import Sequence
from os.path import join as merge_paths

import numpy as np
import pandas as pd
import nibabel as nib

from DLPT.datasets import Dataset
from DLPT.utils.asserts import VALID_MODES


ADNI_CLASSES = ["cn", "mci", "ad"]
DATA_PATH = "/home/diedre/Dropbox/bigdata/Norm_Complete_ADNI_niigz/"
CSV_PATH = "/home/diedre/Dropbox/bigdata/Norm_Complete_ADNI_niigz/Complete_ADNI_3_04_2020.csv"


class ADNI(Dataset):
    '''
    3D ADNI dataset, currently intended for classification.
    '''
    TO_REMOVE = ["013_S_1275"]  # Corrupt file, too small makes no sense.

    def __init__(self, group, mode, data_path=DATA_PATH, csv_path=CSV_PATH, transform=None, sep_mode="holdout",
                 splits=(0.7, 0.1, 0.2), kfold=None, fold=None, target_only=False):
        super(ADNI, self).__init__()
        assert group in ["all"] + ADNI_CLASSES

        csv = pd.read_csv(csv_path)  # read csv with subject information

        self.group = group
        self.mode = mode
        self.transform = transform
        self.target_only = target_only

        subjects = [os.path.basename(path) for path in glob(merge_paths(data_path, "*_S_*"))]  # get all subjects

        # Remove unwanted subjects
        for to_remove in ADNI.TO_REMOVE:
            if to_remove in subjects:
                subjects.remove(to_remove)

        # Fold/mode Selection
        if self.mode != "all":
            subjects = self.get_holdout_or_kfold_set(subjects, mode, sep_mode=sep_mode, splits=splits, kfold=kfold,
                                                     fold=fold)

        # Build dict informing which is the group of each subject
        subject_group = {}
        for subject in subjects:
            found_group = csv.loc[csv["Subject"] == subject]["Group"].values[0].lower()

            # If using a specific group only, remove subjects not from specified group
            if self.group != "all":
                if found_group != self.group:
                    subjects.remove(subject)
            else:  # When using multiple groups, build dict informing what is the group of each subject
                subject_group[subject] = found_group

        # Build list of filepaths and respective level of Alzheimer (target)
        self.file_paths_tgt = []
        for subject in subjects:
            for file_path in iglob(merge_paths(data_path, subject, "**", "*.nii.gz"), recursive=True):
                if self.group == "all":
                    self.file_paths_tgt.append((file_path, subject_group[subject]))
                else:
                    self.file_paths_tgt.append((file_path, self.group))

        logging.info("ADNI initialized with group: {}, mode: {}, data_path: {}, csv_path: {}, transform: {}, sep_mode: {}, "
                     "splits: {}, kfold: {}, fold: {}, nvolumes: {}."
                     "\n".format(self.group, self.mode, data_path, csv_path, self.transform, sep_mode, splits,
                                 kfold, fold, len(self.file_paths_tgt)))
        logging.debug("{} subjects: {}".format(self.mode, subjects))

    def __len__(self) -> int:
        return len(self.file_paths_tgt)

    def __getitem__(self, x: int) -> Sequence:
        path, group = self.file_paths_tgt[x]

        if self.target_only:
            vol = np.ones(10)
        else:
            vol = nib.load(path).get_fdata().astype(np.float32)
        tgt = np.array(ADNI_CLASSES.index(group))

        if self.transform is not None:
            vol, tgt = self.transform(vol, tgt)

        return vol, tgt


def test_adni(display=False, long_test=False):
    from collections import Counter
    for mode in VALID_MODES:
        adni = ADNI("all", mode, target_only=True)
        logging.info(f"{mode} balancing test...")
        tgts = adni.get_all_tgts()
        count = Counter(tgts)
        logging.info(f"{mode} counts: {count}, balancing: {np.array(tgts).mean()} should be around 1.5")

    if long_test:
        for mode in ["all"] + VALID_MODES:
            for group in ["all"] + ADNI_CLASSES:
                if mode != "all":
                    for sep_mode in ["holdout", "kfold"]:
                        if sep_mode == "holdout":
                            adni = ADNI(group, mode, sep_mode=sep_mode)
                            random.choice(adni)
                        else:
                            for kfold in range(2, 6):
                                for fold in range(1, kfold + 1):
                                    adni = ADNI(group, mode, sep_mode=sep_mode, kfold=kfold, fold=fold)
                                    random.choice(adni)
                else:
                    adni = ADNI(group, mode)
                    random.choice(adni)
