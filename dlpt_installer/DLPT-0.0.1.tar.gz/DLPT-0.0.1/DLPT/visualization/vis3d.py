import sys
sys.path.append("/home/diedre/git/diedre_phd/")  # workaround until DLPT becomes a pip package
sys.path.append("/home/diedre/git/diedre_phd/DLPT")  # workaround until DLPT becomes a pip package

import argparse
import time
import multiprocessing as mp
from multiprocessing.queues import Empty
import logging

import numpy as np
import nibabel as nib
from scipy.ndimage import zoom

import matplotlib.pyplot as plt

from DLPT.utils.mri import center_crop_volume


class MatPlot3D():
    def __init__(self, title, plt_show=True):
        self.title = title
        self.plt_show = plt_show
        self.calls = 0
        self.figs = []

    def plot(self, voxels, transform=True, label=None):
        voxels = center_crop_volume(voxels, (80, 80, 80))
        voxels = zoom(voxels, (0.5, 0.5, 0.5), order=0)
        self.calls += 1
        title = "Call: {} - {} - Label: {}".format(self.calls, self.title, '' if label is None else label)
        fig = plt.figure(num=title)
        self.figs.append(fig)
        ax = fig.add_subplot(111, projection='3d')
        ax.voxels(voxels)
        if self.plt_show:
            plt.show()
        else:
            plt.draw()
            plt.pause(0.01)

    def close_all(self):
        for fig in self.figs:
            plt.close(fig)


class Independent3DPlotter():
    '''
    Manages a separate process for matlab plotting
    '''
    def __init__(self, title):
        self.title = title
        self.data_q = mp.Queue()
        self.started = False

    def plot(self, voxels):
        self.data_q.put(voxels)

    def start(self):
        if self.started:
            logging.warning("Plotter already started.")
            return

        self.p = mp.Process(target=plot_loop, args=(self.title, self.data_q))
        self.p.start()
        self.started = True

    def stop(self):
        self.data_q.put("stop")
        self.p.join()
        logging.info("Plotter stopped.")


def plot_loop(title, q):
    '''
    Loop consuming data to plot from queue q.
    Give any string to queue to stop loop (e.g: "stop").
    '''
    mat_plot_3d = MatPlot3D(title, plt_show=False)

    data = None
    while not isinstance(data, str):
        try:
            data = q.get_nowait()
            if isinstance(data, np.ndarray):
                mat_plot_3d.plot(data)
        except Empty:
            plt.pause(1)

    mat_plot_3d.close_all()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--vol", type=str, required=True)
    args = parser.parse_args()

    voxels = nib.load(args.vol).get_fdata()
    voxels = center_crop_volume(voxels, (80, 80, 80))
    voxels = zoom(voxels, (0.5, 0.5, 0.5), order=0)

    plotter = Independent3DPlotter("Teste")
    plotter.start()

    for _ in range(3):
        voxels = zoom(voxels, (0.5, 0.5, 0.5), order=0)
        plotter.plot(voxels)

    for i in range(20, 0, -1):
        print("Ending program in {}s...".format(i), end='\r')
        time.sleep(1)

    plotter.stop()
