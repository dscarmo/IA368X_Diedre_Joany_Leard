'''
Handles random things being always in the same order
'''
import torch
from pytorch_lightning import seed_everything


def deterministic_run(seed=4321):
    '''
    Source: https://pytorch.org/docs/stable/notes/randomness.html
    '''
    seed_everything(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
