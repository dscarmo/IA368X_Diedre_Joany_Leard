'''
Handling of files in the cache folder
'''
import os
from os.path import join as merge_paths
import glob
import logging
import nibabel as nib
import datetime


def cache_a_volume(vol, fid=None):
    '''
    Saves a volume as Nift file in cache folder
    Used for tools that need a path as input
    '''
    cache_path = os.path.join("cache", fid + str(datetime.datetime.now()) + ".nii.gz")
    nib.save(nib.Nifti1Image(vol, affine=None), cache_path)
    return cache_path


def check_cache():
    '''
    Checks cache exists
    '''
    if not os.path.isdir("cache"):
        logging.info("Cache folder not found, creating.")
        os.makedirs("cache")


def clean_all_cache():
    '''
    Cleans all iles found on the cache folder.
    '''
    try:
        fils = glob.glob(merge_paths("cache", '*'))
        if len(fils) > 0:
            logging.info("Cleaning cache...")
            for fil in fils:
                logging.info("Deleting {}".format(fil))
                os.remove(fil)
            logging.info("Cache cleaned successfully.")
    except Exception:
        logging.error("Cache cleaning problem!", exc_info=True)


def clear_cache(*fids):
    '''
    Clears volumes in a fid array, or all cache volumes
    '''
    toremove = []
    if len(fids) == 0:
        for filename in glob.iglob(os.path.join("cache", "*")):
            toremove.append(filename)
    else:
        for fid in fids:
            for filename in glob.iglob(os.path.join("cache", "{}*".format(fid))):
                toremove.append(filename)

    for file_to_remove in toremove:
        try:
            os.remove(file_to_remove)
        except FileNotFoundError:
            print("Trying to remove unexistent file {} in cache.".format(filename))
        except Exception as e:
            print("Internal error in cache clearance: {}".format(e))
