'''
Functions related to graphics interfaceing
'''
from tkinter import Tk
from tkinter.filedialog import askopenfilename
from tkinter import messagebox


# Simple GUI utils
def file_dialog():
    '''
    Simple GUI to chose files
    '''
    Tk().withdraw()  # we don't want a full GUI, so keep the root window from appearing
    filename = askopenfilename()  # show an "Open" dialog box and return the path to the selected file
    if filename:
        return filename
    else:  # if empty return None
        return None


def alert_dialog(msg, title="E2D HipSeg"):
    Tk().withdraw()  # we don't want a full GUI, so keep the root window from appearing
    messagebox.showinfo(title, msg)


def error_dialog(msg, title="E2D HipSeg"):
    Tk().withdraw()  # we don't want a full GUI, so keep the root window from appearing
    messagebox.showerror(title, msg)


def confirm_dialog(msg, title='E2D HipSeg'):
    '''
    Simple confirmation dialog
    '''
    Tk().withdraw()  # we don't want a full GUI, so keep the root window from appearing
    MsgBox = messagebox.askquestion(title, msg)
    if MsgBox == 'yes':
        return True
    else:
        return False
