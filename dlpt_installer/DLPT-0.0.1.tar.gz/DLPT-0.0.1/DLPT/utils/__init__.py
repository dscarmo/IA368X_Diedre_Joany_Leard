'''
This package has general utility functions that dont fit in a specific package
'''
