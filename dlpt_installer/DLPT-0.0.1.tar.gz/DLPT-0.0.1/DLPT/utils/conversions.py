'''
Implements conversions from different types
'''
import torch
import numpy as np
from torch import Tensor
from scipy.ndimage import distance_transform_edt as distance

from DLPT.utils.asserts import sset, simplex, one_hot


def class2one_hot(seg: Tensor, C: int) -> Tensor:
    if len(seg.shape) == 2:  # Only w, h, used by the dataloader
        seg = seg.unsqueeze(dim=0)
    assert sset(seg, list(range(C)))

    b, w, h = seg.shape

    res = torch.stack([seg == c for c in range(C)], dim=1).type(torch.int32)
    assert res.shape == (b, C, w, h)
    assert one_hot(res)

    return res


# switch between representations
def probs2class(probs: Tensor) -> Tensor:
    b, _, w, h = probs.shape
    assert simplex(probs)

    res = probs.argmax(dim=1)
    assert res.shape == (b, w, h)

    return res


def probs2one_hot(probs: Tensor) -> Tensor:
    _, C, _, _ = probs.shape
    assert simplex(probs)

    res = class2one_hot(probs2class(probs), C)
    assert res.shape == probs.shape
    assert one_hot(res)

    return res


def one_hot2dist(seg: np.ndarray) -> np.ndarray:
    assert one_hot(torch.Tensor(seg), axis=0)
    C: int = len(seg)

    res = np.zeros_like(seg)
    for c in range(C):
        posmask = seg[c].astype(np.bool)

        if posmask.any():
            negmask = ~posmask
            res[c] = distance(negmask) * negmask - (distance(posmask) - 1) * posmask
    return res


# Adapted from genius idea on stackoverflow
def all_idx(idx, axis):
    grid = np.ogrid[tuple(map(slice, idx.shape))]
    grid.insert(axis, idx)
    return tuple(grid)


def int_to_onehot(matrix, onehot_type=np.dtype(np.float32), overhide_max=None):
    '''
    Converts a matrix of int values (will try to convert) to one hot vectors
    '''
    if overhide_max is None:
        vec_len = int(matrix.max() + 1)
    else:
        vec_len = overhide_max

    onehot = np.zeros((vec_len,) + matrix.shape, dtype=onehot_type)

    int_matrix = matrix.astype(np.int)

    onehot[all_idx(int_matrix, axis=0)] = 1

    return onehot
