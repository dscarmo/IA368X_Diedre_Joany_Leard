'''
Iterable management functions
'''


def chunks(l, n):
    '''
    Yield successive n-sized chunks from iterable.
    '''
    for i in range(0, len(l), n):
        yield l[i:i + n]
